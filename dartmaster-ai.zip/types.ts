export interface Player {
  id: string;
  name: string;
  alias: string;
  avatarUrl: string;
  score: number;
}

export enum GameMode {
  X01 = '501 Double Out',
  CRICKET = 'Cricket',
  CLOCK = 'Around the Clock',
  KILLER = 'Killer',
  SHANGHAI = 'Shanghai',
  X01_301 = '301 Double In/Out'
}

export interface GameConfig {
  mode: GameMode;
  target?: number;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  timestamp: number;
}
