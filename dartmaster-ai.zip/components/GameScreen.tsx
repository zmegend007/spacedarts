import React, { useState, useEffect } from 'react';
import { Player, GameMode } from '../types';
import { Mic, ArrowLeft, Trophy } from 'lucide-react';
import { generateHostSpeech } from '../services/gemini';
import { globalAudioQueue } from '../services/audioUtils';
import ChatAssistant from './ChatAssistant';

interface GameScreenProps {
  mode: GameMode;
  player: Player;
  onExit: () => void;
}

const GameScreen: React.FC<GameScreenProps> = ({ mode, player, onExit }) => {
  const [currentScore, setCurrentScore] = useState<number>(0);
  const [roundHistory, setRoundHistory] = useState<number[]>([]);
  const [inputScore, setInputScore] = useState<string>('');
  
  // Initial Score logic based on mode
  useEffect(() => {
    let start = 0;
    if (mode === GameMode.X01) start = 501;
    if (mode === GameMode.X01_301) start = 301;
    if (mode === GameMode.CRICKET) start = 0; // Simple Cricket scoring for demo
    setCurrentScore(start);
    
    // Announce start
    playVoice(`Welcome to ${mode}. ${player.alias}, step up to the oche!`);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode, player.alias]);

  const playVoice = async (text: string) => {
    try {
        const audioBase64 = await generateHostSpeech(text);
        if (audioBase64) {
            await globalAudioQueue.playBase64(audioBase64);
        }
    } catch (e) {
        console.error("Audio playback error", e);
    }
  };

  const handleScoreSubmit = () => {
    const points = parseInt(inputScore);
    if (isNaN(points)) return;

    let newScore = currentScore;
    let message = '';

    if (mode === GameMode.X01 || mode === GameMode.X01_301) {
        if (currentScore - points < 0 || currentScore - points === 1) {
             message = `Bust! You scored ${points} but needed ${currentScore}.`;
        } else {
             newScore = currentScore - points;
             message = `${points} scored! ${newScore} remaining.`;
             if (points > 100) message = `Wow! A massive ${points}! ${newScore} left.`;
             if (newScore === 0) message = `Game Shot! ${player.alias} wins the leg!`;
        }
    } else {
        // Basic additive scoring for other modes for simplicity in this demo
        newScore = currentScore + points;
        message = `${points} points. Total is ${newScore}.`;
    }

    setCurrentScore(newScore);
    setRoundHistory([...roundHistory, points]);
    setInputScore('');
    playVoice(message);
  };

  return (
    <div className="min-h-screen bg-dart-dark flex flex-col">
      {/* Header */}
      <div className="bg-dart-panel p-4 flex justify-between items-center shadow-md">
        <button onClick={onExit} className="text-gray-400 hover:text-white flex items-center space-x-1">
          <ArrowLeft className="h-5 w-5" />
          <span>Exit Game</span>
        </button>
        <div className="flex items-center space-x-3">
          <img src={player.avatarUrl} alt={player.alias} className="w-10 h-10 rounded-full border border-dart-accent" />
          <span className="font-bold text-white hidden sm:inline">{player.alias}</span>
        </div>
      </div>

      {/* Score Display */}
      <div className="flex-1 flex flex-col items-center justify-center p-4">
        <h2 className="text-dart-gold uppercase tracking-widest text-sm mb-2">{mode}</h2>
        <div className="bg-dart-panel p-8 rounded-3xl border-4 border-dart-neon shadow-[0_0_20px_rgba(15,52,96,0.5)] min-w-[300px] text-center mb-8">
            <h1 className="text-8xl font-bold text-white brand-font tabular-nums">
                {currentScore}
            </h1>
        </div>

        {/* Keypad */}
        <div className="w-full max-w-sm">
            <div className="flex space-x-2 mb-4">
                <input 
                    type="number" 
                    value={inputScore}
                    readOnly
                    className="flex-1 bg-gray-800 text-white text-3xl font-bold p-4 rounded-lg text-center"
                    placeholder="0"
                />
                <button 
                    onClick={handleScoreSubmit}
                    className="bg-dart-green hover:bg-green-600 text-white px-6 rounded-lg font-bold"
                >
                    ENTER
                </button>
            </div>
            
            <div className="grid grid-cols-3 gap-3">
                {[1, 2, 3, 4, 5, 6, 7, 8, 9].map(num => (
                    <button 
                        key={num}
                        onClick={() => setInputScore(prev => prev + num)}
                        className="bg-dart-panel hover:bg-gray-700 text-white text-2xl font-bold py-4 rounded-lg transition-colors border-b-4 border-gray-900 active:border-b-0 active:translate-y-1"
                    >
                        {num}
                    </button>
                ))}
                <button 
                    onClick={() => setInputScore(prev => prev.slice(0, -1))}
                    className="bg-red-900/50 hover:bg-red-900 text-white font-bold py-4 rounded-lg"
                >
                    DEL
                </button>
                <button 
                    onClick={() => setInputScore(prev => prev + '0')}
                    className="bg-dart-panel hover:bg-gray-700 text-white text-2xl font-bold py-4 rounded-lg border-b-4 border-gray-900 active:border-b-0 active:translate-y-1"
                >
                    0
                </button>
                 <button 
                    onClick={() => { setInputScore(''); setCurrentScore(mode === GameMode.X01 ? 501 : 0); playVoice("Game Reset!"); }}
                    className="bg-gray-700 hover:bg-gray-600 text-white font-bold py-4 rounded-lg"
                >
                    RST
                </button>
            </div>
        </div>
      </div>
      
      {/* Floating Chat */}
      <ChatAssistant />
    </div>
  );
};

export default GameScreen;
